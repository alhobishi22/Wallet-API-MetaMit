from app import db, app
import os
import psycopg2
from psycopg2 import sql
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def init_db():
    # First use Flask's built-in SQLAlchemy
    with app.app_context():
        # Drop all existing tables
        db.drop_all()
        
        # Create all tables
        db.create_all()
        
        print("تم تهيئة قاعدة بيانات SQLAlchemy بنجاح!")
    
    # Now create the table directly with psycopg2 to ensure all fields
    try:
        DATABASE_URL = os.getenv('DATABASE_URL')
        conn = psycopg2.connect(DATABASE_URL)
        cur = conn.cursor()
        
        # Drop table if exists
        cur.execute("DROP TABLE IF EXISTS kyc_application CASCADE")
        
        # Create table with all necessary fields
        cur.execute("""
            CREATE TABLE kyc_application (
                id SERIAL PRIMARY KEY,
                application_id VARCHAR(50) UNIQUE NOT NULL,
                full_name VARCHAR(100) NOT NULL,
                phone_number VARCHAR(20) NOT NULL,
                address VARCHAR(200) NOT NULL,
                id_photo_url VARCHAR(200) NOT NULL,
                selfie_photo_url VARCHAR(200) NOT NULL,
                status VARCHAR(20) DEFAULT 'pending',
                registration_code VARCHAR(50),
                rejection_reason TEXT,
                telegram_chat_id VARCHAR(50),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        conn.commit()
        cur.close()
        conn.close()
        
        print("تم تهيئة جدول طلبات التوثيق بنجاح!")
    except Exception as e:
        print(f"خطأ أثناء تهيئة قاعدة البيانات: {str(e)}")

if __name__ == '__main__':
    init_db()
