import os
from flask import Flask, render_template, request, jsonify, redirect, url_for
from dotenv import load_dotenv
import cloudinary
import cloudinary.uploader
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import base64
import asyncio
from telegram_notifier import send_kyc_notification

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL')
if app.config['SQLALCHEMY_DATABASE_URI'].startswith('postgres://'):
    app.config['SQLALCHEMY_DATABASE_URI'] = app.config['SQLALCHEMY_DATABASE_URI'].replace('postgres://', 'postgresql://', 1)

# Initialize extensions
db = SQLAlchemy(app)
CORS(app)

# Configure Cloudinary
cloudinary.config(
    cloud_name=os.getenv('CLOUDINARY_CLOUD_NAME'),
    api_key=os.getenv('CLOUDINARY_API_KEY'),
    api_secret=os.getenv('CLOUDINARY_API_SECRET')
)

# Create tables
with app.app_context():
    db.create_all()

# Define models
class KYCApplication(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    application_id = db.Column(db.String(50), unique=True, nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    phone_number = db.Column(db.String(20), nullable=False)
    address = db.Column(db.String(200), nullable=False)
    id_photo_url = db.Column(db.String(200), nullable=False)
    selfie_photo_url = db.Column(db.String(200), nullable=False)
    status = db.Column(db.String(20), default='pending')
    registration_code = db.Column(db.String(50), nullable=True)
    rejection_reason = db.Column(db.Text, nullable=True)
    telegram_chat_id = db.Column(db.String(50), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

def upload_base64_to_cloudinary(base64_image):
    # إزالة بداية سلسلة Base64 إذا كانت موجودة
    if 'base64,' in base64_image:
        base64_image = base64_image.split('base64,')[1]
    
    try:
        # رفع الصورة إلى Cloudinary
        result = cloudinary.uploader.upload(
            f"data:image/jpeg;base64,{base64_image}",
            folder="kyc_photos",  # مجلد لتنظيم الصور
            resource_type="image"
        )
        return result['secure_url']
    except Exception as e:
        print(f"خطأ في رفع الصورة: {str(e)}")
        return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/submit_kyc', methods=['POST'])
def submit_kyc():
    try:
        # التأكد من أن البيانات بتنسيق JSON
        if not request.is_json:
            return jsonify({
                'success': False,
                'message': 'يجب إرسال البيانات بتنسيق JSON'
            }), 400

        data = request.get_json()
        
        # التحقق من البيانات المطلوبة
        required_fields = ['fullName', 'phoneNumber', 'address', 'idPhoto', 'selfiePhoto']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'message': f'حقل {field} مطلوب'
                }), 400

        # رفع الصور إلى Cloudinary
        id_photo_url = upload_base64_to_cloudinary(data['idPhoto'])
        selfie_photo_url = upload_base64_to_cloudinary(data['selfiePhoto'])
        
        if not id_photo_url or not selfie_photo_url:
            return jsonify({
                'success': False,
                'message': 'فشل في رفع الصور'
            }), 400

        # إنشاء رقم طلب فريد
        application_id = f"KYC-{datetime.now().strftime('%Y%m%d')}-{os.urandom(4).hex()}"

        # إنشاء سجل جديد في قاعدة البيانات
        application = KYCApplication(
            application_id=application_id,
            full_name=data['fullName'],
            phone_number=data['phoneNumber'],
            address=data['address'],
            id_photo_url=id_photo_url,
            selfie_photo_url=selfie_photo_url,
            telegram_chat_id=data.get('telegramChatId')  # تخزين معرف تلغرام للمستخدم
        )

        # حفظ في قاعدة البيانات
        db.session.add(application)
        db.session.commit()
        
        # إعداد بيانات الإشعار
        notification_data = {
            'fullName': data['fullName'],
            'phone': data['phoneNumber'],
            'address': data['address'],
            'idCardFrontImage': id_photo_url,
            'selfieImage': selfie_photo_url,
            'requestId': application_id,
            'telegramChatId': data.get('telegramChatId')  # إضافة معرف تلغرام لبيانات الإشعار
        }
        
        # محاولة إرسال إشعار عبر تلغرام (بشكل غير متزامن)
        # لكن عدم السماح بفشل العملية بأكملها إذا فشل الإشعار
        try:
            # استخدام طريقة آمنة لتشغيل asyncio
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            # تجربة إرسال الإشعار مع وقت انتظار محدود
            loop.run_until_complete(asyncio.wait_for(
                send_kyc_notification(notification_data), 
                timeout=5.0  # تحديد مهلة 5 ثوانٍ للإرسال
            ))
            loop.close()
        except asyncio.TimeoutError:
            print("تجاوز وقت إرسال الإشعار المحدد")
        except Exception as e:
            print(f"خطأ في إرسال الإشعار: {str(e)}")
            # في حالة فشل الإشعار، سنحاول تخزين بيانات الإشعار لإرسالها لاحقًا
            # (يمكن إضافة آلية مستقبلية لإعادة محاولة الإرسال)

        # إرجاع استجابة النجاح بغض النظر عن نجاح إرسال الإشعار
        return jsonify({
            'success': True,
            'application_id': application_id,
            'message': 'تم إرسال الطلب بنجاح'
        })

    except Exception as e:
        db.session.rollback()
        print(f"خطأ في حفظ الطلب: {str(e)}")
        return jsonify({
            'success': False,
            'message': 'حدث خطأ أثناء معالجة الطلب'
        }), 500

@app.route('/status/<int:application_id>')
def check_status(application_id):
    application = KYCApplication.query.get(application_id)
    
    if application:
        return render_template('status.html', application={
            'id': application.id,
            'status': application.status,
            'created_at': application.created_at
        })
    return render_template('status.html', error='Application not found')

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 10000))
    app.run(host='0.0.0.0', port=port)
