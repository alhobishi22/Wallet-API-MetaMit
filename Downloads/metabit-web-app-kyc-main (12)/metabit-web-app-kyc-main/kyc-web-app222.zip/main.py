import os
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
import asyncio
import logging
import requests
from dotenv import load_dotenv
import uvicorn
import json
from telegram import Update, WebAppInfo, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes, MessageHandler, filters
import psycopg2
from psycopg2 import sql
from datetime import datetime
from telegram_notifier import (
    send_notification_to_user, 
    send_kyc_notification, 
    validate_chat_id, 
    update_telegram_message
)

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
ADMIN_GROUP_ID = os.getenv('ADMIN_GROUP_ID')
WEB_APP_URL = "https://metabit-kyc-v2.onrender.com"

# التحقق من وجود متغيرات البيئة الضرورية
if not TELEGRAM_BOT_TOKEN:
    logger.error("TELEGRAM_BOT_TOKEN not found in environment variables!")
    TELEGRAM_BOT_TOKEN = "missing_token"  # قيمة افتراضية لتجنب الأخطاء
    
if not ADMIN_GROUP_ID:
    logger.error("ADMIN_GROUP_ID not found in environment variables!")
    ADMIN_GROUP_ID = "0"  # قيمة افتراضية لتجنب الأخطاء

logger.info(f"Bot Token: {TELEGRAM_BOT_TOKEN[:5] if TELEGRAM_BOT_TOKEN else 'Not Set'}...")
logger.info(f"Admin Group ID: {ADMIN_GROUP_ID}")

app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    """Root endpoint for the application"""
    return {
        "app": "MetaBit KYC Verification System",
        "version": "1.0.0",
        "status": "running"
    }

# Global bot application
bot_app = None

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle the /start command"""
    keyboard = [
        [InlineKeyboardButton("بدء التوثيق 🔐", web_app=WebAppInfo(url=WEB_APP_URL))]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    welcome_message = "مرحباً بك في بوت التوثيق! 👋\nيرجى الضغط على الزر أدناه لبدء عملية التوثيق."
    
    # تخزين معرف الدردشة
    user_id = update.effective_user.id
    await update.message.reply_text(welcome_message, reply_markup=reply_markup)
    
    logger.info(f"Start command sent to user {user_id}")
    
    # تحديث قاعدة البيانات بمعرف المستخدم في تلغرام للطلبات التي قد تكون مرتبطة برقم الهاتف
    try:
        # تلغرام لا يوفر رقم الهاتف مباشرة، لذا سنستخدم فقط اسم المستخدم
        user_name = update.effective_user.full_name
        user_id = update.effective_user.id
        
        if user_name:
            DATABASE_URL = os.getenv('DATABASE_URL')
            conn = psycopg2.connect(DATABASE_URL)
            cur = conn.cursor()
            
            # تحديث الطلبات المعلقة التي لا تحتوي على معرف دردشة
            update_query = """
                UPDATE kyc_application 
                SET telegram_chat_id = %s
                WHERE telegram_chat_id IS NULL 
                  AND status = 'pending'
                  AND full_name = %s
            """
            
            cur.execute(update_query, (user_id, user_name))
            affected_rows = cur.rowcount
            conn.commit()
            
            if affected_rows > 0:
                logger.info(f"تم تحديث {affected_rows} من الطلبات بمعرف المستخدم {user_id}")
            
            cur.close()
            conn.close()
            
    except Exception as e:
        logger.error(f"خطأ في تحديث معرف المستخدم: {str(e)}")

# Global variables for conversation state
user_states = {}

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle callback queries from inline buttons"""
    query = update.callback_query
    data = query.data
    
    await query.answer()
    
    if data.startswith("approve_"):
        request_id = data.split("_")[1]
        
        # Set user state to waiting for registration code
        admin_id = update.effective_user.id
        user_states[admin_id] = {
            "action": "approve",
            "request_id": request_id,
            "awaiting_message": True,
            "original_message_id": query.message.message_id,
            "original_chat_id": query.message.chat_id
        }
        
        # إنشاء أزرار للرجوع
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("رجوع 🔙", callback_data=f"back_{request_id}")]
        ])
        
        await query.message.reply_text(
            f"🔐 الرجاء إدخال رمز التسجيل للطلب {request_id}:",
            reply_markup=keyboard
        )
        
    elif data.startswith("reject_"):
        request_id = data.split("_")[1]
        
        # Set user state to waiting for rejection reason
        admin_id = update.effective_user.id
        user_states[admin_id] = {
            "action": "reject",
            "request_id": request_id,
            "awaiting_message": True,
            "original_message_id": query.message.message_id,
            "original_chat_id": query.message.chat_id
        }
        
        # إنشاء أزرار للرجوع
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("رجوع 🔙", callback_data=f"back_{request_id}")]
        ])
        
        await query.message.reply_text(
            f"❌ الرجاء إدخال سبب رفض الطلب {request_id}:",
            reply_markup=keyboard
        )
        
    elif data.startswith("back_"):
        request_id = data.split("_")[1]
        
        # Reset user state if they were in the middle of approving/rejecting
        admin_id = update.effective_user.id
        if admin_id in user_states:
            user_states.pop(admin_id, None)
        
        # الحصول على معلومات الطلب من قاعدة البيانات
        try:
            DATABASE_URL = os.getenv('DATABASE_URL')
            conn = psycopg2.connect(DATABASE_URL)
            cur = conn.cursor()
            
            query = sql.SQL("""
                SELECT application_id, full_name, phone_number, telegram_chat_id
                FROM kyc_application 
                WHERE application_id = %s
            """)
            cur.execute(query, (request_id,))
            result = cur.fetchone()
            
            if result:
                application_id, full_name, phone_number, telegram_chat_id = result
                
                # إنشاء أزرار القبول والرفض من جديد
                keyboard = InlineKeyboardMarkup([
                    [
                        InlineKeyboardButton("قبول ✅", callback_data=f"approve_{request_id}"),
                        InlineKeyboardButton("رفض ❌", callback_data=f"reject_{request_id}")
                    ]
                ])
                
                # إعادة إرسال رسالة الطلب
                message = (
                    "🔔 *طلب توثيق جديد*\n\n"
                    f"*رقم الطلب:* {application_id}\n"
                    f"*الاسم:* {full_name}\n"
                    f"*رقم الهاتف:* {phone_number}\n"
                    f"*معرف تلغرام:* {telegram_chat_id or 'غير متوفر'}"
                )
                
                await query.edit_message_text(
                    text=message,
                    reply_markup=keyboard,
                    parse_mode='Markdown'
                )
            else:
                await query.edit_message_text(f"لم يتم العثور على طلب برقم {request_id}")
                
            cur.close()
            conn.close()
            
        except Exception as e:
            logger.error(f"Error retrieving application: {str(e)}")
            await query.edit_message_text(f"حدث خطأ أثناء استرجاع بيانات الطلب: {str(e)}")

async def handle_admin_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle admin messages for approving/rejecting KYC requests"""
    # تحقق إذا كان المستخدم مشرفًا أو كانت الرسالة من مجموعة المشرفين
    is_admin_user = await is_admin(update, context)
    
    if not is_admin_user:
        # تسجيل المحاولة غير المصرح بها مع معلومات أكثر للتشخيص
        user_id = update.effective_user.id
        username = update.effective_user.username or "بدون اسم مستخدم"
        chat_id = update.effective_chat.id
        logger.info(f"⛔ رسالة من مستخدم غير مصرح له - المعرف: {user_id}, اسم المستخدم: {username}, معرف الدردشة: {chat_id}")
        return
    
    # سجل معلومات المعالجة للتشخيص
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    admin_group_id = os.getenv('ADMIN_GROUP_ID')
    
    if str(chat_id) == str(admin_group_id):
        logger.info(f"✅ معالجة رسالة من مجموعة المشرفين (المستخدم: {user_id})")
    else:
        logger.info(f"✅ معالجة رسالة مباشرة من مشرف معتمد (المستخدم: {user_id})")
    
    # الحصول على معلومات المشرف
    admin_username = update.effective_user.username or "غير معروف"
    admin_first_name = update.effective_user.first_name or ""
    admin_last_name = update.effective_user.last_name or ""
    admin_full_name = f"{admin_first_name} {admin_last_name}".strip() or admin_username
    
    # التحقق مما إذا كان المشرف في حالة انتظار إدخال 
    if user_id in user_states and user_states[user_id]["awaiting_message"]:
        state = user_states[user_id]
        action = state["action"]
        request_id = state["request_id"]
        content = update.message.text
        
        logger.info(f"🔄 إكمال إجراء المشرف: {action} للطلب {request_id} بمحتوى: {content}")
        
        # إعادة تعيين حالة المستخدم
        user_states[user_id]["awaiting_message"] = False
        
        # معالجة الإجراء بناءً على نوعه
        if action == "approve":
            await process_approval(update, request_id, content, admin_full_name)
        elif action == "reject":
            await process_rejection(update, request_id, content, admin_full_name)
        
        return
    
    # معالجة الرسائل العادية باستخدام الأوامر
    text = update.message.text
    parts = text.split()
    
    if len(parts) < 3:
        logger.info(f"⚠️ صيغة الأمر غير صحيحة: {text}")
        await update.message.reply_text(
            "⚠️ صيغة الأمر غير صحيحة. يجب أن تكون الصيغة:\n\n"
            "للقبول: `code رقم_الطلب الكود`\n"
            "للرفض: `reject رقم_الطلب سبب_الرفض`",
            parse_mode="Markdown"
        )
        return
    
    action = parts[0]
    request_id = parts[1]
    content = " ".join(parts[2:])  # استخدام مسافة بدلاً من _
    
    logger.info(f"🔄 إجراء المشرف: {action} للطلب {request_id} بواسطة {admin_full_name}")
    
    # معالجة الإجراء
    if action.lower() == "code":
        await process_approval(update, request_id, content, admin_full_name)
    elif action.lower() == "reject":
        await process_rejection(update, request_id, content, admin_full_name)
    else:
        await update.message.reply_text(
            "⚠️ أمر غير معروف. الأوامر المتاحة هي:\n\n"
            "- `code` لقبول طلب\n"
            "- `reject` لرفض طلب",
            parse_mode="Markdown"
        )

async def process_approval(update, request_id, registration_code, admin_full_name):
    """Process KYC application approval"""
    try:
        DATABASE_URL = os.getenv('DATABASE_URL')
        conn = psycopg2.connect(DATABASE_URL)
        cur = conn.cursor()
        
        # الحصول على معلومات أكثر عن الطلب والمستخدم
        query = sql.SQL("""
            SELECT telegram_chat_id, full_name, phone_number
            FROM kyc_application 
            WHERE application_id = %s
        """)
        cur.execute(query, (request_id,))
        result = cur.fetchone()
        
        if not result:
            await update.message.reply_text(f"❌ لم يتم العثور على طلب بالرقم {request_id}")
            return
            
        user_chat_id, full_name, phone_number = result
        
        # تحديث حالة الطلب إلى "approved"
        update_query = sql.SQL("""
            UPDATE kyc_application 
            SET status = 'approved', 
                admin_name = %s,
                registration_code = %s,
                updated_at = NOW(),
                is_closed = TRUE
            WHERE application_id = %s
            RETURNING id
        """)
        cur.execute(update_query, (admin_full_name, registration_code, request_id))
        
        if cur.rowcount > 0:
            # تم التحديث بنجاح
            await update.message.reply_text(
                f"✅ تمت الموافقة على الطلب {request_id} بنجاح!\n"
                f"📝 كود التسجيل: `{registration_code}`\n"
                f"🧑‍💼 تمت المعالجة بواسطة: {admin_full_name}",
                parse_mode="Markdown"
            )
            
            conn.commit()
            
            # تحديث رسالة الطلب الأصلية وإزالة الأزرار
            admin_id = update.effective_user.id
            if admin_id in user_states and "original_message_id" in user_states[admin_id] and "original_chat_id" in user_states[admin_id]:
                # الحصول على معرف الرسالة ومعرف المحادثة من حالة المستخدم
                original_message_id = user_states[admin_id]["original_message_id"]
                original_chat_id = user_states[admin_id]["original_chat_id"]
                
                try:
                    # إنشاء نص الرسالة المحدثة
                    request_message = f"الرجاء اتخاذ قرار بشأن طلب التوثيق (رقم: {request_id})"
                    updated_text = f"{request_message}\n\n✅ *تمت الموافقة على الطلب بنجاح*\n📝 كود التسجيل: `{registration_code}`\n🧑‍💼 تمت المعالجة بواسطة: {admin_full_name}"
                    
                    # تحديث الرسالة بدون أزرار
                    success = await update_telegram_message(
                        original_chat_id,
                        original_message_id,
                        updated_text,
                        "Markdown"
                    )
                    
                    if success:
                        logger.info(f"تم تحديث رسالة الطلب الأصلية وإزالة الأزرار")
                    else:
                        logger.error(f"فشل في تحديث رسالة الطلب الأصلية")
                except Exception as e:
                    logger.error(f"خطأ في تحديث رسالة الطلب: {str(e)}")
            
            # إرسال إشعار للمستخدم
            if user_chat_id:
                try:
                    user_message = (
                        f"🎉 *تهانينا {full_name}!*\n\n"
                        f"تمت الموافقة على طلب التوثيق الخاص بك.\n\n"
                        f"*رقم الطلب:* {request_id}\n"
                        f"*كود التسجيل:* `{registration_code}`\n"
                        f"*تمت المعالجة بواسطة:* {admin_full_name}\n\n"
                        f"يمكنك استخدام هذا الكود للدخول إلى الخدمات المتاحة."
                    )
                    
                    # محاولة إرسال الإشعار مع إعادة المحاولة عند الفشل
                    max_attempts = 1
                    attempt = 0
                    success = False
                    
                    # للتطوير فقط - استخدم معرف دردشة عام للاختبار إذا كان المعرف غير متوفر
                    admin_telegram_id = int(os.getenv('ADMIN_TELEGRAM_ID', '0'))
                    test_mode = os.getenv('TEST_MODE', 'False').lower() == 'true'
                    
                    if test_mode and admin_telegram_id and (user_chat_id is None or str(user_chat_id).strip() == ''):
                        logger.info(f"وضع الاختبار: استخدام معرف المشرف {admin_telegram_id} لإرسال الإشعار")
                        user_chat_id = admin_telegram_id
                        
                    logger.info(f"محاولة إرسال إشعار إلى المستخدم. معرف الدردشة: {user_chat_id}")
                    
                    while attempt < max_attempts and not success:
                        attempt += 1
                        success = await send_kyc_notification(user_chat_id, user_message, "Markdown")
                        if not success and attempt < max_attempts:
                            await asyncio.sleep(2 * attempt)  # زيادة فترة الانتظار مع كل محاولة
                    
                    if not success:
                        await update.message.reply_text(
                            f"⚠️ فشلت جميع محاولات إرسال الإشعار للمستخدم. "
                            f"يرجى التأكد من أن المستخدم قام بتفعيل البوت."
                        )
                except Exception as e:
                    logger.error(f"خطأ في إرسال الإشعار للمستخدم: {str(e)}")
                    await update.message.reply_text(
                        f"⚠️ تمت الموافقة على الطلب ولكن فشل إرسال الإشعار للمستخدم: {str(e)}"
                    )
        else:
            await update.message.reply_text(f"❌ حدث خطأ أثناء تحديث الطلب {request_id}")
            
        cur.close()
        conn.close()
        
    except Exception as e:
        logger.error(f"خطأ في معالجة الموافقة على الطلب: {str(e)}")
        await update.message.reply_text(f"❌ حدث خطأ أثناء معالجة الطلب: {str(e)}")

async def process_rejection(update, request_id, reason, admin_full_name):
    """Process KYC application rejection"""
    try:
        DATABASE_URL = os.getenv('DATABASE_URL')
        conn = psycopg2.connect(DATABASE_URL)
        cur = conn.cursor()
        
        # الحصول على معلومات أكثر عن الطلب والمستخدم
        query = sql.SQL("""
            SELECT telegram_chat_id, full_name
            FROM kyc_application 
            WHERE application_id = %s
        """)
        cur.execute(query, (request_id,))
        result = cur.fetchone()
        
        if not result:
            await update.message.reply_text(f"❌ لم يتم العثور على طلب بالرقم {request_id}")
            return
            
        user_chat_id, full_name = result
        
        # تحديث حالة الطلب إلى "rejected"
        update_query = sql.SQL("""
            UPDATE kyc_application 
            SET status = 'rejected', 
                admin_name = %s,
                rejection_reason = %s,
                updated_at = NOW(),
                is_closed = TRUE
            WHERE application_id = %s
            RETURNING id
        """)
        cur.execute(update_query, (admin_full_name, reason, request_id))
        
        if cur.rowcount > 0:
            # تم التحديث بنجاح
            await update.message.reply_text(
                f"✅ تم رفض الطلب {request_id} بنجاح!\n"
                f"📝 سبب الرفض: {reason}\n"
                f"🧑‍💼 تمت المعالجة بواسطة: {admin_full_name}"
            )
            
            conn.commit()
            
            # تحديث رسالة الطلب الأصلية وإزالة الأزرار
            admin_id = update.effective_user.id
            if admin_id in user_states and "original_message_id" in user_states[admin_id] and "original_chat_id" in user_states[admin_id]:
                # الحصول على معرف الرسالة ومعرف المحادثة من حالة المستخدم
                original_message_id = user_states[admin_id]["original_message_id"]
                original_chat_id = user_states[admin_id]["original_chat_id"]
                
                try:
                    # إنشاء نص الرسالة المحدثة
                    request_message = f"الرجاء اتخاذ قرار بشأن طلب التوثيق (رقم: {request_id})"
                    updated_text = f"{request_message}\n\n❌ *تم رفض الطلب*\n📝 سبب الرفض: {reason}\n🧑‍💼 تمت المعالجة بواسطة: {admin_full_name}"
                    
                    # تحديث الرسالة بدون أزرار
                    success = await update_telegram_message(
                        original_chat_id,
                        original_message_id,
                        updated_text,
                        "Markdown"
                    )
                    
                    if success:
                        logger.info(f"تم تحديث رسالة الطلب الأصلية وإزالة الأزرار بعد الرفض")
                    else:
                        logger.error(f"فشل في تحديث رسالة الطلب الأصلية بعد الرفض")
                except Exception as e:
                    logger.error(f"خطأ في تحديث رسالة الطلب بعد الرفض: {str(e)}")
            
            # إرسال إشعار للمستخدم
            if user_chat_id:
                try:
                    user_message = (
                        f"⚠️ *عزيزي {full_name}،*\n\n"
                        f"للأسف، تم رفض طلب التوثيق الخاص بك.\n\n"
                        f"*رقم الطلب:* {request_id}\n"
                        f"*سبب الرفض:* {reason}\n"
                        f"*تمت المعالجة بواسطة:* {admin_full_name}\n\n"
                        f"يمكنك التواصل مع الدعم الفني للمزيد من المعلومات."
                    )
                    
                    # محاولة إرسال الإشعار مع إعادة المحاولة عند الفشل
                    max_attempts = 3
                    attempt = 0
                    success = False
                    
                    # للتطوير فقط - استخدم معرف دردشة عام للاختبار إذا كان المعرف غير متوفر
                    admin_telegram_id = int(os.getenv('ADMIN_TELEGRAM_ID', '0'))
                    test_mode = os.getenv('TEST_MODE', 'False').lower() == 'true'
                    
                    if test_mode and admin_telegram_id and (user_chat_id is None or str(user_chat_id).strip() == ''):
                        logger.info(f"وضع الاختبار: استخدام معرف المشرف {admin_telegram_id} لإرسال الإشعار")
                        user_chat_id = admin_telegram_id
                        
                    logger.info(f"محاولة إرسال إشعار إلى المستخدم. معرف الدردشة: {user_chat_id}")
                    
                    while attempt < max_attempts and not success:
                        attempt += 1
                        success = await send_kyc_notification(user_chat_id, user_message, "Markdown")
                        if not success and attempt < max_attempts:
                            await asyncio.sleep(2 * attempt)  # زيادة فترة الانتظار مع كل محاولة
                    
                    if not success:
                        await update.message.reply_text(
                            f"⚠️ فشلت جميع محاولات إرسال الإشعار للمستخدم. "
                            f"يرجى التأكد من أن المستخدم قام بتفعيل البوت."
                        )
                except Exception as e:
                    logger.error(f"خطأ في إرسال الإشعار للمستخدم: {str(e)}")
                    await update.message.reply_text(
                        f"⚠️ تم رفض الطلب ولكن فشل إرسال الإشعار للمستخدم: {str(e)}"
                    )
        else:
            await update.message.reply_text(f"❌ حدث خطأ أثناء تحديث الطلب {request_id}")
            
        cur.close()
        conn.close()
        
    except Exception as e:
        logger.error(f"خطأ في معالجة رفض الطلب: {str(e)}")
        await update.message.reply_text(f"❌ حدث خطأ أثناء معالجة الطلب: {str(e)}")

async def update_telegram_ids(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Actualizar manualmente los IDs de Telegram en la base de datos"""
    if not await is_admin(update, context):
        await update.message.reply_text("⛔ هذا الأمر متاح فقط للمشرفين")
        return
    
    try:
        # الحصول على معرف المستخدم ورقم الهاتف من الرسالة
        command_parts = update.message.text.split()
        if len(command_parts) < 3:
            await update.message.reply_text("📝 استخدام: /update_id <application_id> <telegram_chat_id>")
            return
        
        application_id = command_parts[1]
        telegram_chat_id = int(command_parts[2])
        
        # تحديث قاعدة البيانات
        DATABASE_URL = os.getenv('DATABASE_URL')
        conn = psycopg2.connect(DATABASE_URL)
        cur = conn.cursor()
        
        update_query = """
            UPDATE kyc_application 
            SET telegram_chat_id = %s
            WHERE application_id = %s
            RETURNING full_name
        """
        
        cur.execute(update_query, (telegram_chat_id, application_id))
        result = cur.fetchone()
        conn.commit()
        
        if result:
            full_name = result[0]
            await update.message.reply_text(
                f"✅ تم تحديث معرف تلغرام للطلب {application_id}\n"
                f"الاسم: {full_name}\n"
                f"معرف تلغرام الجديد: {telegram_chat_id}"
            )
        else:
            await update.message.reply_text(f"❌ لم يتم العثور على طلب بالرقم {application_id}")
        
        cur.close()
        conn.close()
        
    except ValueError:
        await update.message.reply_text("❌ يجب أن يكون معرف تلغرام رقمًا صحيحًا")
    except Exception as e:
        logger.error(f"خطأ في تحديث معرف تلغرام: {str(e)}")
        await update.message.reply_text(f"❌ حدث خطأ: {str(e)}")

async def resend_notification(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """إعادة إرسال الإشعارات يدوياً للمستخدم"""
    if not await is_admin(update, context):
        await update.message.reply_text("⛔ هذا الأمر متاح فقط للمشرفين")
        return
    
    try:
        # الحصول على معلومات المستخدم والرسالة
        command_parts = update.message.text.split(maxsplit=2)
        if len(command_parts) < 3:
            await update.message.reply_text("📝 استخدام: /resend <telegram_chat_id> <نص الرسالة>")
            return
        
        telegram_chat_id = int(command_parts[1])
        message = command_parts[2]
        
        # إعلام المشرف بأن الإرسال قيد التقدم
        await update.message.reply_text(f"⏳ جاري إرسال الإشعار إلى المستخدم {telegram_chat_id}...")
        
        # إرسال الإشعار
        max_attempts = 3
        attempt = 0
        success = False
        
        while attempt < max_attempts and not success:
            attempt += 1
            logger.info(f"محاولة {attempt} لإرسال الإشعار إلى المستخدم {telegram_chat_id}")
            success = await send_kyc_notification(telegram_chat_id, message, "Markdown")
            if not success and attempt < max_attempts:
                await asyncio.sleep(2 * attempt)  # زيادة فترة الانتظار مع كل محاولة
        
        if success:
            await update.message.reply_text(f"✅ تم إرسال الإشعار بنجاح إلى المستخدم {telegram_chat_id}")
        else:
            await update.message.reply_text(f"❌ فشلت جميع محاولات إرسال الإشعار إلى المستخدم {telegram_chat_id}")
        
    except ValueError:
        await update.message.reply_text("❌ يجب أن يكون معرف تلغرام رقمًا صحيحًا")
    except Exception as e:
        logger.error(f"خطأ في إرسال الإشعار: {str(e)}")
        await update.message.reply_text(f"❌ حدث خطأ: {str(e)}")

@app.post("/api/kyc-submission")
async def handle_kyc_submission(request: Request):
    """Handle KYC submission from the web app and notify admins via Telegram"""
    try:
        logger.info("Received a new KYC submission request")
        
        # Get the JSON data from the request
        kyc_data = await request.json()
        logger.info(f"Parsed request data: {kyc_data}")
        
        request_id = kyc_data.get('requestId', 'غير متوفر')
        telegram_chat_id = kyc_data.get('telegramChatId')
        
        # تسجيل وتنظيف معرف الدردشة
        if telegram_chat_id:
            try:
                telegram_chat_id = int(str(telegram_chat_id).strip())
                logger.info(f"معرف الدردشة في تلغرام بعد التنظيف: {telegram_chat_id}")
            except (ValueError, TypeError):
                logger.warning(f"تم استلام معرف دردشة غير صالح: {telegram_chat_id}")
                telegram_chat_id = None
        
        logger.info(f"Received KYC submission with request ID: {request_id}, Telegram chat ID: {telegram_chat_id}")
        
        # Save to database
        try:
            # Create database connection
            DATABASE_URL = os.getenv('DATABASE_URL')
            if not DATABASE_URL:
                logger.error("DATABASE_URL not set in environment variables")
                return {
                    "status": "error",
                    "message": "Database configuration missing"
                }
                
            conn = psycopg2.connect(DATABASE_URL)
            cur = conn.cursor()
            
            # Create KYC application record
            query = """
                INSERT INTO kyc_application 
                (application_id, full_name, phone_number, address, id_photo_url, selfie_photo_url, status, telegram_chat_id) 
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            
            cur.execute(query, (
                request_id,
                kyc_data.get('fullName', 'غير متوفر'),
                kyc_data.get('phone', 'غير متوفر'),
                kyc_data.get('address', 'غير متوفر'),
                kyc_data.get('idCardFrontImage', ''),
                kyc_data.get('selfieImage', ''),
                'pending',
                telegram_chat_id
            ))
            
            conn.commit()
            cur.close()
            conn.close()
            logger.info(f"Successfully saved KYC application to database")
        except Exception as db_error:
            logger.error(f"Error saving to database: {str(db_error)}")
        
        # Format message
        message = (
            f"🔔 *طلب توثيق جديد*\n\n"
            f"*رقم الطلب:* {request_id}\n"
            f"*الاسم:* {kyc_data.get('fullName', 'غير متوفر')}\n"
            f"*رقم الهاتف:* {kyc_data.get('phone', 'غير متوفر')}\n"
            f"*البريد الإلكتروني:* {kyc_data.get('email', 'غير متوفر')}\n"
            f"*رقم الهوية:* {kyc_data.get('idNumber', 'غير متوفر')}\n"
        )
        
        # Send text message
        logger.info(f"Attempting to send notification to admin group: {ADMIN_GROUP_ID}")
        if TELEGRAM_BOT_TOKEN == "missing_token":
            logger.error("TELEGRAM_BOT_TOKEN is missing, cannot send notification")
            return {
                "status": "error",
                "message": "Telegram Bot Token is missing"
            }
        
        text_result = send_notification_to_user(ADMIN_GROUP_ID, message, "Markdown")
        logger.info(f"Notification result: {text_result}")
        
        if not text_result.get("ok"):
            logger.error(f"Failed to send text message: {text_result}")
            return {
                "status": "error",
                "message": f"Error sending to Telegram: {text_result.get('description')}"
            }
        
        # Send images if available
        if 'idCardFrontImage' in kyc_data and kyc_data['idCardFrontImage']:
            send_notification_to_user(
                ADMIN_GROUP_ID,
                "صورة الهوية (الأمام) 🪪",
                "Markdown",
                photo=kyc_data['idCardFrontImage']
            )
        
        if 'idCardBackImage' in kyc_data and kyc_data['idCardBackImage']:
            send_notification_to_user(
                ADMIN_GROUP_ID,
                "صورة الهوية (الخلف) 🪪",
                "Markdown",
                photo=kyc_data['idCardBackImage']
            )
        
        if 'selfieImage' in kyc_data and kyc_data['selfieImage']:
            send_notification_to_user(
                ADMIN_GROUP_ID,
                "الصورة الشخصية 🤳",
                "Markdown",
                photo=kyc_data['selfieImage']
            )
        
        # Create keyboard for admin approval/rejection
        keyboard = {
            "inline_keyboard": [
                [
                    {"text": "قبول ✅", "callback_data": f"approve_{request_id}"},
                    {"text": "رفض ❌", "callback_data": f"reject_{request_id}"}
                ]
            ]
        }
        
        # Send a message with the approval buttons
        approve_message = f"الرجاء اتخاذ قرار بشأن طلب التوثيق (رقم: {request_id})"
        
        approve_result = requests.post(
            f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
            json={
                "chat_id": ADMIN_GROUP_ID,
                "text": approve_message,
                "reply_markup": keyboard
            }
        ).json()
        
        logger.info(f"Admin approval message sent: {approve_result.get('ok')}")
        
        return {
            "status": "success",
            "message": "KYC submission received and admins notified"
        }
        
    except Exception as e:
        logger.error(f"Error in handle_kyc_submission: {str(e)}")
        return {
            "status": "error",
            "message": str(e)
        }

@app.get("/api/kyc-status/{application_id}")
async def check_kyc_status(application_id: str):
    """Check the status of a KYC application"""
    try:
        DATABASE_URL = os.getenv('DATABASE_URL')
        conn = psycopg2.connect(DATABASE_URL)
        cur = conn.cursor()
        
        # Get the application status
        query = sql.SQL("""
            SELECT status, registration_code, rejection_reason 
            FROM kyc_application 
            WHERE application_id = %s
        """)
        cur.execute(query, (application_id,))
        result = cur.fetchone()
        
        cur.close()
        conn.close()
        
        if not result:
            return {
                "status": "error",
                "message": "Application not found"
            }
        
        status, registration_code, rejection_reason = result
        
        response = {
            "status": "success",
            "application_status": status,
        }
        
        if status == "approved" and registration_code:
            response["registration_code"] = registration_code
        
        if status == "rejected" and rejection_reason:
            response["rejection_reason"] = rejection_reason
        
        return response
        
    except Exception as e:
        logger.error(f"Error checking KYC status: {str(e)}")
        return {
            "status": "error",
            "message": str(e)
        }

@app.get("/api/health")
async def health_check():
    """Health check endpoint that also tests database connection"""
    try:
        # Get Database URL from environment
        DATABASE_URL = os.getenv('DATABASE_URL')
        if not DATABASE_URL:
            return {
                "status": "warning",
                "database": "DATABASE_URL not set",
                "bot": "active" if TELEGRAM_BOT_TOKEN != "missing_token" else "not configured"
            }
            
        # Test database connection
        conn = psycopg2.connect(DATABASE_URL)
        cur = conn.cursor()
        cur.execute("SELECT 1")
        cur.close()
        conn.close()
        
        return {
            "status": "healthy",
            "database": "connected",
            "bot": "active" if TELEGRAM_BOT_TOKEN != "missing_token" else "not configured"
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e),
            "database": "error",
            "bot": "active" if TELEGRAM_BOT_TOKEN != "missing_token" else "not configured"
        }

async def run_bot():
    """Run the Telegram bot"""
    global bot_app
    
    # Skip bot initialization if no valid token
    if TELEGRAM_BOT_TOKEN == "missing_token":
        logger.warning("Skipping Telegram bot initialization - no valid token")
        return
    
    # Create the application
    bot_app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
    
    # Register handlers
    bot_app.add_handler(CommandHandler("start", start_command))
    bot_app.add_handler(CallbackQueryHandler(handle_callback))
    
    # Add message handler for processing admin responses (approvals/rejections)
    bot_app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_admin_message))
    bot_app.add_handler(CommandHandler("update_id", update_telegram_ids))
    bot_app.add_handler(CommandHandler("resend", resend_notification))
    bot_app.add_handler(CommandHandler("list_requests", list_pending_requests))
    
    # Start the bot in a non-blocking way
    try:
        await bot_app.initialize()
        await bot_app.start()
        
        # Start polling for messages
        await bot_app.updater.start_polling()
        
        logger.info("Telegram Bot started successfully.")
    except Exception as e:
        logger.error(f"Error starting Telegram bot: {str(e)}")
        bot_app = None

async def run_fastapi():
    """Run the FastAPI server"""
    config = uvicorn.Config(app, host="0.0.0.0", port=8888)
    server = uvicorn.Server(config)
    await server.serve()

async def main():
    """Run both the bot and FastAPI server"""
    await asyncio.gather(
        run_bot(),
        run_fastapi()
    )

async def list_pending_requests(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """عرض قائمة طلبات KYC المعلقة"""
    if not await is_admin(update, context):
        await update.message.reply_text("⛔ هذا الأمر متاح فقط للمشرفين")
        return
    
    try:
        DATABASE_URL = os.getenv('DATABASE_URL')
        conn = psycopg2.connect(DATABASE_URL)
        cur = conn.cursor()
        
        # استعلام عن الطلبات المعلقة
        query = """
            SELECT application_id, full_name, status, telegram_chat_id, created_at
            FROM kyc_application
            WHERE status = 'pending' OR status = 'in_review'
            ORDER BY created_at DESC
            LIMIT 10
        """
        
        cur.execute(query)
        results = cur.fetchall()
        
        if not results:
            await update.message.reply_text("🔍 لا توجد طلبات معلقة حالياً")
            return
            
        # بناء الرسالة
        message = "📋 *قائمة الطلبات المعلقة:*\n\n"
        
        for result in results:
            application_id, full_name, status, telegram_chat_id, created_at = result
            status_emoji = "⏳" if status == "pending" else "🔍"
            telegram_status = "✅" if telegram_chat_id else "❌"
            
            message += f"{status_emoji} *{application_id}*\n"
            message += f"👤 الاسم: `{full_name}`\n"
            message += f"📱 حالة تلغرام: {telegram_status}\n"
            message += f"📅 التاريخ: {created_at.strftime('%Y-%m-%d %H:%M')}\n\n"
        
        message += "\nلإرسال إشعار، استخدم:\n`/resend <telegram_chat_id> <نص الرسالة>`"
        
        await update.message.reply_text(message, parse_mode="Markdown")
        
        cur.close()
        conn.close()
        
    except Exception as e:
        logger.error(f"خطأ في عرض الطلبات المعلقة: {str(e)}")
        await update.message.reply_text(f"❌ حدث خطأ: {str(e)}")

async def is_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Check if the user is an admin"""
    user_id = update.effective_user.id
    
    try:
        # التحقق أولاً إذا كان المستخدم هو المشرف الرئيسي
        admin_telegram_id = os.getenv('ADMIN_TELEGRAM_ID')
        if admin_telegram_id and str(user_id) == str(admin_telegram_id):
            logger.info(f"المستخدم {user_id} هو المشرف الرئيسي")
            return True
            
        # التحقق إذا كان المستخدم عضوًا في مجموعة المشرفين
        admin_group_id = os.getenv('ADMIN_GROUP_ID')
        if not admin_group_id:
            logger.warning("لم يتم تعيين معرف مجموعة المشرفين")
            return False
            
        # اعتبار الرسائل من المجموعة نفسها مسموح بها دائمًا
        if str(update.effective_chat.id) == str(admin_group_id):
            return True
            
        # التحقق من عضوية المستخدم في المجموعة
        try:
            chat_member = await context.bot.get_chat_member(chat_id=admin_group_id, user_id=user_id)
            if chat_member.status in ['member', 'administrator', 'creator']:
                logger.info(f"المستخدم {user_id} هو عضو في مجموعة المشرفين")
                return True
        except Exception as e:
            logger.error(f"خطأ في التحقق من عضوية المجموعة: {str(e)}")
        
        return False
        
    except Exception as e:
        logger.error(f"خطأ في التحقق من صلاحيات المشرف: {str(e)}")
        return False

if __name__ == "__main__":
    asyncio.run(main())
