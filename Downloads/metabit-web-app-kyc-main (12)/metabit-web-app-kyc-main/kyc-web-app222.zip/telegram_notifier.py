import os
import logging
import aiohttp
import asyncio
import requests
from dotenv import load_dotenv
from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup, InputMediaPhoto
from telegram.ext import CallbackQueryHandler

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
ADMIN_GROUP_ID = int(os.getenv('ADMIN_GROUP_ID')) if os.getenv('ADMIN_GROUP_ID') else None

# وظيفة أساسية لإرسال الإشعارات
async def send_telegram_message(chat_id, message, parse_mode=None, photo=None, reply_markup=None):
    """
    وظيفة أساسية لإرسال رسائل تلغرام (نص أو صور)
    """
    try:
        if not chat_id:
            logger.warning("لم يتم تحديد معرف دردشة")
            return False

        # تنظيف معرف الدردشة
        if isinstance(chat_id, str):
            chat_id = chat_id.strip()
            if chat_id.startswith('@'):
                chat_id = chat_id[1:]
            try:
                chat_id = int(chat_id)
            except ValueError:
                logger.warning(f"معرف دردشة غير صالح: {chat_id}")
                return False

        # التحقق من أن المعرف رقم صحيح موجب
        if chat_id <= 0:
            logger.warning(f"معرف دردشة غير صالح (سالب أو صفر): {chat_id}")
            return False

        # إنشاء البوت
        bot = Bot(token=TELEGRAM_BOT_TOKEN)

        try:
            if photo:
                # إرسال صورة
                await bot.send_photo(
                    chat_id=chat_id,
                    photo=photo,
                    caption=message,
                    parse_mode=parse_mode,
                    reply_markup=reply_markup
                )
            else:
                # إرسال نص
                await bot.send_message(
                    chat_id=chat_id,
                    text=message,
                    parse_mode=parse_mode,
                    reply_markup=reply_markup
                )
            
            logger.info(f"تم إرسال الإشعار بنجاح للمستخدم {chat_id}")
            return True
        
        except Exception as e:
            logger.error(f"خطأ في إرسال الإشعار للمستخدم: {str(e)}")
            
            # محاولة إرسال الإشعار باستخدام الطريقة البديلة
            logger.info(f"محاولة إرسال الإشعار باستخدام الطريقة البديلة...")
            
            # استخدام HTTP API مباشرة
            api_url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
            if photo:
                api_url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendPhoto"
            
            payload = {
                "chat_id": chat_id,
                "text": message,
                "parse_mode": parse_mode
            }
            
            if photo:
                payload = {
                    "chat_id": chat_id,
                    "photo": photo,
                    "caption": message,
                    "parse_mode": parse_mode
                }
            
            if reply_markup:
                payload["reply_markup"] = reply_markup.to_dict() if hasattr(reply_markup, 'to_dict') else reply_markup
            
            # سجل الطلب للتشخيص
            logger.info(f"إرسال طلب HTTP إلى {api_url} مع chat_id={chat_id}")
            
            # إرسال الطلب
            async with aiohttp.ClientSession() as session:
                async with session.post(api_url, json=payload) as response:
                    response_text = await response.text()
                    logger.info(f"استجابة Telegram API: {response_text}")
                    
                    try:
                        result = await response.json()
                        
                        if result.get("ok"):
                            if photo:
                                logger.info(f"تم إرسال الصورة بنجاح عبر HTTP للمستخدم {chat_id}")
                            else:
                                logger.info(f"تم إرسال الإشعار بنجاح عبر HTTP للمستخدم {chat_id}")
                            return True
                        else:
                            error_desc = result.get('description', 'خطأ غير معروف')
                            logger.error(f"فشل في إرسال الإشعار عبر HTTP: {error_desc}")
                            return False
                    except Exception as json_error:
                        logger.error(f"خطأ في تحليل استجابة JSON: {str(json_error)}")
                        return False
        
        finally:
            try:
                await bot.close()
            except Exception as e:
                logger.error(f"خطأ عند إغلاق اتصال البوت: {str(e)}")
    
    except Exception as e:
        logger.error(f"خطأ في إرسال الإشعار: {str(e)}")
        return False

# وظيفة لإرسال إشعار للمستخدم
async def send_user_notification(chat_id, message, parse_mode=None, photo=None):
    """
    إرسال إشعار للمستخدم
    """
    return await send_telegram_message(chat_id, message, parse_mode, photo)

# وظيفة لإرسال مجموعة صور
async def send_media_group(chat_id, media_list):
    """
    إرسال مجموعة من الصور
    """
    try:
        bot = Bot(token=TELEGRAM_BOT_TOKEN)
        await bot.send_media_group(chat_id=chat_id, media=media_list)
        logger.info(f"تم إرسال مجموعة الصور بنجاح إلى {chat_id}")
        return True
    except Exception as e:
        logger.error(f"خطأ في إرسال مجموعة الصور: {str(e)}")
        return False
    finally:
        try:
            await bot.close()
        except Exception as e:
            logger.error(f"خطأ عند إغلاق اتصال البوت: {str(e)}")

# وظيفة لإرسال إشعار بطلب KYC جديد إلى المشرفين
async def send_admin_notification(kyc_data):
    """
    إرسال إشعار بطلب KYC جديد إلى مجموعة المشرفين
    """
    try:
        request_id = kyc_data.get('requestId', 'غير متوفر')
        logger.info(f"معالجة طلب KYC برقم: {request_id}")
        
        # جمع تفاصيل الطلب في رسالة
        application_info = (
            "🔔 *طلب توثيق جديد*\n\n"
            f"*رقم الطلب:* {request_id}\n"
            f"*الاسم:* {kyc_data.get('fullName', 'غير متوفر')}\n"
            f"*رقم الهاتف:* {kyc_data.get('phone', 'غير متوفر')}\n"
            f"*العنوان:* {kyc_data.get('address', 'غير متوفر')}\n"
            f"*معرف تلغرام:* {kyc_data.get('telegramChatId', 'غير متوفر')}"
        )
        
        logger.info(f"إرسال رسالة إلى مجموعة المشرفين: {ADMIN_GROUP_ID}")
        
        # إنشاء أزرار القبول والرفض
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("قبول ✅", callback_data=f"approve_{request_id}"),
                InlineKeyboardButton("رفض ❌", callback_data=f"reject_{request_id}")
            ]
        ])
        
        # تحضير الصور للإرسال
        has_id_photo = 'idCardFrontImage' in kyc_data and kyc_data['idCardFrontImage']
        has_selfie = 'selfieImage' in kyc_data and kyc_data['selfieImage']
        
        # إرسال الصور مع معلومات الطلب
        try:
            # إنشاء البوت
            bot = Bot(token=TELEGRAM_BOT_TOKEN)
            
            if has_id_photo and has_selfie:
                # إرسال مجموعة من الصور مع تفاصيل الطلب
                logger.info("إرسال مجموعة الصور مع معلومات الطلب")
                
                # جمع وسائط الصور
                media = [
                    InputMediaPhoto(media=kyc_data['idCardFrontImage'], caption=application_info, parse_mode="Markdown"),
                    InputMediaPhoto(media=kyc_data['selfieImage'])
                ]
                
                try:
                    # إرسال مجموعة الصور
                    sent_messages = await bot.send_media_group(
                        chat_id=ADMIN_GROUP_ID,
                        media=media
                    )
                    
                    # إرسال أزرار التفاعل في رسالة منفصلة مباشرة بعد الصور
                    if sent_messages:
                        message = await bot.send_message(
                            chat_id=ADMIN_GROUP_ID,
                            text=f"الرجاء اتخاذ قرار بشأن طلب التوثيق (رقم: {request_id})",
                            reply_markup=keyboard,
                            reply_to_message_id=sent_messages[0].message_id  # الرد على الرسالة الأولى في المجموعة
                        )
                        
                        logger.info("تم إرسال مجموعة الصور مع معلومات الطلب بنجاح")
                        return True
                except Exception as e:
                    logger.error(f"خطأ في إرسال مجموعة الصور: {str(e)}")
                    # سنحاول الطريقة البديلة في حالة الفشل
            
            # إذا فشلت محاولة إرسال مجموعة الصور أو لا توجد صور متعددة
            # فسنرسل صورة واحدة مع معلومات الطلب
            
            if has_id_photo:
                # إرسال صورة الهوية مع معلومات الطلب وأزرار
                id_photo_sent = await send_telegram_message(
                    ADMIN_GROUP_ID,
                    application_info,
                    "Markdown",
                    kyc_data['idCardFrontImage'],
                    keyboard
                )
                if id_photo_sent:
                    logger.info("تم إرسال صورة الهوية مع معلومات الطلب بنجاح")
                    
                    # إرسال الصورة الشخصية كرسالة منفصلة إذا كانت متوفرة
                    if has_selfie:
                        await asyncio.sleep(1)  # تأخير بين الرسائل
                        selfie_sent = await send_telegram_message(
                            ADMIN_GROUP_ID,
                            "🤳 *الصورة الشخصية*",
                            "Markdown",
                            kyc_data['selfieImage']
                        )
                        if selfie_sent:
                            logger.info("تم إرسال الصورة الشخصية بنجاح")
                    
                    return True
                else:
                    logger.error("فشل في إرسال صورة الهوية مع معلومات الطلب")
            
            # إذا فشلت محاولة إرسال صورة الهوية أو لم تكن موجودة
            # نحاول إرسال الصورة الشخصية مع المعلومات
            elif has_selfie:
                # إرسال الصورة الشخصية مع معلومات الطلب وأزرار
                selfie_sent = await send_telegram_message(
                    ADMIN_GROUP_ID,
                    application_info,
                    "Markdown",
                    kyc_data['selfieImage'],
                    keyboard
                )
                if selfie_sent:
                    logger.info("تم إرسال الصورة الشخصية مع معلومات الطلب بنجاح")
                    return True
                else:
                    logger.error("فشل في إرسال الصورة الشخصية مع معلومات الطلب")
            
            # إذا لم توجد صور أو فشلت جميع المحاولات السابقة، نرسل المعلومات فقط
            else:
                info_sent = await send_telegram_message(
                    ADMIN_GROUP_ID,
                    application_info,
                    'Markdown',
                    None,
                    keyboard
                )
                if info_sent:
                    logger.info("تم إرسال معلومات الطلب بنجاح (بدون صور)")
                    return True
                else:
                    logger.error("فشل في إرسال معلومات الطلب")
                    return False
                
        except Exception as e:
            logger.error(f"خطأ في إرسال الإشعار مع الصور: {str(e)}")
            
            # نحاول إرسال المعلومات فقط في حالة الفشل
            try:
                info_sent = await send_telegram_message(
                    ADMIN_GROUP_ID,
                    application_info,
                    'Markdown',
                    None,
                    keyboard
                )
                if info_sent:
                    logger.info("تم إرسال معلومات الطلب بنجاح (بدون صور، بعد فشل محاولة الصور)")
                    return True
                else:
                    logger.error("فشل في إرسال معلومات الطلب")
                    return False
            except Exception as e2:
                logger.error(f"خطأ في إرسال معلومات الطلب بعد فشل محاولة الصور: {str(e2)}")
                return False
        
    except Exception as e:
        logger.error(f"خطأ في إرسال إشعار تلغرام: {e}")
        return False

# Non-async version for direct API calls
def send_notification_to_user(chat_id, message, parse_mode=None, photo=None, reply_markup=None):
    """
    إرسال إشعار للمستخدم (نسخة غير متزامنة)
    """
    try:
        if not chat_id:
            logger.warning("لم يتم تحديد معرف دردشة")
            return {"ok": False, "description": "Chat ID not provided"}

        # تنظيف معرف الدردشة
        if isinstance(chat_id, str):
            chat_id = chat_id.strip()
            if chat_id.startswith('@'):
                chat_id = chat_id[1:]
            try:
                chat_id = int(chat_id)
            except ValueError:
                logger.warning(f"معرف دردشة غير صالح: {chat_id}")
                return {"ok": False, "description": "Invalid chat ID format"}

        # التحقق من أن المعرف رقم صحيح موجب
        if chat_id <= 0:
            logger.warning(f"معرف دردشة غير صالح (سالب أو صفر): {chat_id}")
            return {"ok": False, "description": "Invalid chat ID value"}

        if photo:
            # إرسال صورة
            api_url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendPhoto"
            payload = {
                "chat_id": chat_id,
                "photo": photo,
                "caption": message,
                "parse_mode": parse_mode
            }
        else:
            # إرسال نص
            api_url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
            payload = {
                "chat_id": chat_id,
                "text": message,
                "parse_mode": parse_mode
            }

        if reply_markup:
            payload["reply_markup"] = reply_markup.to_dict() if hasattr(reply_markup, 'to_dict') else reply_markup

        # إرسال الطلب
        response = requests.post(api_url, json=payload)
        result = response.json()

        if result.get("ok"):
            if photo:
                logger.info(f"تم إرسال الصورة بنجاح إلى {chat_id}")
            else:
                logger.info(f"تم إرسال الإشعار بنجاح إلى {chat_id}")
        else:
            error_desc = result.get('description', 'خطأ غير معروف')
            logger.error(f"فشل في إرسال الإشعار: {error_desc}")

        return result

    except Exception as e:
        logger.error(f"خطأ في إرسال الإشعار: {str(e)}")
        return {"ok": False, "description": str(e)}

# وظيفة لإرسال إشعار KYC
async def send_kyc_notification(chat_id, message, parse_mode=None, photo=None, reply_markup=None):
    """
    إرسال إشعار KYC (نسخة متزامنة)
    """
    # استخدام وظيفة send_telegram_message للإرسال
    try:
        return await send_telegram_message(chat_id, message, parse_mode, photo, reply_markup)
    except Exception as e:
        logger.error(f"خطأ في إرسال إشعار KYC: {str(e)}")
        return False

# وظيفة للتحقق من صحة معرف المحادثة
def validate_chat_id(chat_id):
    """
    التحقق من صحة معرف المحادثة
    """
    if not chat_id:
        return False

    # تنظيف معرف الدردشة
    if isinstance(chat_id, str):
        chat_id = chat_id.strip()
        if chat_id.startswith('@'):
            chat_id = chat_id[1:]
        try:
            chat_id = int(chat_id)
        except ValueError:
            return False

    # التحقق من أن المعرف رقم صحيح موجب
    if chat_id <= 0:
        return False

    return True

# وظيفة لتحديث رسالة موجودة في تلغرام
async def update_telegram_message(chat_id, message_id, text, parse_mode=None, reply_markup=None):
    """
    تحديث رسالة موجودة في تلغرام
    """
    try:
        if not chat_id or not message_id:
            logger.warning("لم يتم تحديد معرف دردشة أو معرف رسالة")
            return False

        # إنشاء البوت
        bot = Bot(token=TELEGRAM_BOT_TOKEN)

        try:
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                parse_mode=parse_mode,
                reply_markup=reply_markup
            )
            
            logger.info(f"تم تحديث الرسالة {message_id} بنجاح في الدردشة {chat_id}")
            return True
        
        except Exception as e:
            logger.error(f"خطأ في تحديث الرسالة: {str(e)}")
            
            # محاولة إرسال الرسالة باستخدام الطريقة البديلة
            logger.info(f"محاولة تحديث الرسالة باستخدام الطريقة البديلة...")
            
            # استخدام HTTP API مباشرة
            api_url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/editMessageText"
            
            payload = {
                "chat_id": chat_id,
                "message_id": message_id,
                "text": text,
                "parse_mode": parse_mode
            }
            
            if reply_markup:
                payload["reply_markup"] = reply_markup.to_dict() if hasattr(reply_markup, 'to_dict') else reply_markup
            
            # سجل الطلب للتشخيص
            logger.info(f"إرسال طلب HTTP إلى {api_url} مع chat_id={chat_id}, message_id={message_id}")
            
            # إرسال الطلب
            async with aiohttp.ClientSession() as session:
                async with session.post(api_url, json=payload) as response:
                    response_text = await response.text()
                    logger.info(f"استجابة Telegram API: {response_text}")
                    
                    try:
                        result = await response.json()
                        
                        if result.get("ok"):
                            logger.info(f"تم تحديث الرسالة بنجاح عبر HTTP")
                            return True
                        else:
                            error_desc = result.get('description', 'خطأ غير معروف')
                            logger.error(f"فشل في تحديث الرسالة عبر HTTP: {error_desc}")
                            return False
                    except Exception as json_error:
                        logger.error(f"خطأ في تحليل استجابة JSON: {str(json_error)}")
                        return False
        
        finally:
            try:
                await bot.close()
            except Exception as e:
                logger.error(f"خطأ عند إغلاق اتصال البوت: {str(e)}")
    
    except Exception as e:
        logger.error(f"خطأ في تحديث الرسالة: {str(e)}")
        return False